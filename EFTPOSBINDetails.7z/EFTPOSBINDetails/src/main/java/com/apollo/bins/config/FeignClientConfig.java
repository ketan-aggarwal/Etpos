package com.apollo.bins.config;

import feign.Feign;
import feign.Logger;
import feign.httpclient.ApacheHttpClient;
import feign.slf4j.Slf4jLogger;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.context.annotation.Bean;
import javax.net.ssl.SSLContext;
import java.security.cert.X509Certificate;

public class FeignClientConfig {

   @Bean
    public Feign.Builder feignBuilder() throws Exception{
        return Feign.builder()
                .client(new ApacheHttpClient(disableSslHttpClient()))
                .logger(new Slf4jLogger(Feign.class))
                .logLevel(Logger.Level.FULL);
    }

      @Bean
       public CloseableHttpClient disableSslHttpClient() throws Exception{
            SSLContext sslContext = SSLContextBuilder.create().loadTrustMaterial(null,(X509Certificate[] chain, String authType) -> true).build();

            return HttpClientBuilder.create().setSSLContext(sslContext)
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
        }
    }

