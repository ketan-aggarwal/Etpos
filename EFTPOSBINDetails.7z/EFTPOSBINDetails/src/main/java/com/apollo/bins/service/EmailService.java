//import org.apache.commons.csv.CSVFormat;
//import org.apache.commons.csv.CSVPrinter;
//import org.springframework.stereotype.Service;
//
//import java.io.*;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.*;
//import java.util.stream.Collectors;
//
//@Service
//public class BinComparisonService {
//
//    private static final String PREVIOUS_BIN_FILE_PATH = "previous_bins.csv";
//
//    public Map<String, File> fetchAndCompareBins() {
//        try {
//            // Fetch the current list of BINs from the external service
//            List<BinInfoModel> currentBinList = fetchCurrentBinList();
//
//            // Load the previous BIN list from the existing zCSV file
//            List<BinInfoModel> previousBinList = loadPreviousBinList();
//
//            // Compare the lists to identify differences
//            List<BinInfoModel> differenceBinList = compareBinLists(previousBinList, currentBinList);
//
//            // Create updated BIN CSV
//            File updatedBinFile = createUpdatedBinCsv(currentBinList);
//
//            // Create difference BIN CSV (only if differences exist)
//            File differenceBinFile = null;
//            if (!differenceBinList.isEmpty()) {
//                differenceBinFile = createDifferenceBinCsv(differenceBinList);
//            }
//
//            // Replace the previous BIN file with the updated file for the next comparison
//            saveCurrentBinAsPrevious(currentBinList);
//
//            // Return both files in a map
//            Map<String, File> resultFiles = new HashMap<>();
//            resultFiles.put("updated", updatedBinFile);
//            resultFiles.put("difference", differenceBinFile);
//
//            return resultFiles;
//
//        } catch (Exception e) {
//            throw new RuntimeException("Error while fetching and comparing BINs: " + e.getMessage(), e);
//        }
//    }
//
//    private List<BinInfoModel> fetchCurrentBinList() {
//        // Mocked logic to simulate fetching from an external service
//        return Arrays.asList(
//                new BinInfoModel("123456", "TypeA", "SubType1", "2024-11-20", "2024-11-21", List.of("TX1", "TX2"), "BinName1", "ShortName1", "16", true),
//                new BinInfoModel("654321", "TypeB", "SubType2", "2024-11-21", "2024-11-22", List.of("TX3", "TX4"), "BinName2", "ShortName2", "16", true)
//        );
//    }
//
//    private List<BinInfoModel> loadPreviousBinList() {
//        File file = new File(PREVIOUS_BIN_FILE_PATH);
//        if (!file.exists()) {
//            return Collections.emptyList();
//        }
//
//        try (BufferedReader reader = Files.newBufferedReader(Paths.get(PREVIOUS_BIN_FILE_PATH))) {
//            return reader.lines()
//                    .skip(1) // Skip header row
//                    .map(line -> {
//                        String[] parts = line.split(",");
//                        return new BinInfoModel(parts[0], parts[1], parts[2], parts[3], parts[4], Arrays.asList(parts[5].split(";")), parts[6], parts[7], parts[8], Boolean.parseBoolean(parts[9]));
//                    })
//                    .collect(Collectors.toList());
//        } catch (IOException e) {
//            throw new RuntimeException("Error reading previous BIN file: " + e.getMessage(), e);
//        }
//    }
//
//    private List<BinInfoModel> compareBinLists(List<BinInfoModel> previousBinList, List<BinInfoModel> currentBinList) {
//        Set<String> previousBins = previousBinList.stream().map(BinInfoModel::getBin).collect(Collectors.toSet());
//        return currentBinList.stream()
//                .filter(bin -> !previousBins.contains(bin.getBin()))
//                .collect(Collectors.toList());
//    }
//
//    private File createUpdatedBinCsv(List<BinInfoModel> currentBinList) {
//        return createCsvFile(currentBinList, "updated_bins_" + getCurrentTimestamp() + ".csv");
//    }
//
//    private File createDifferenceBinCsv(List<BinInfoModel> differenceBinList) {
//        return createCsvFile(differenceBinList, "difference_bins_" + getCurrentTimestamp() + ".csv");
//    }
//
//    private File createCsvFile(List<BinInfoModel> binList, String fileName) {
//        File file = new File(fileName);
//        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(file.getPath()));
//             CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader(
//                     "Bin", "BinType", "BinSubType", "LastUpdated", "AvailableDate", "TxAllow", "Name", "ShortName", "PanLength", "IsActive"))) {
//
//            for (BinInfoModel bin : binList) {
//                csvPrinter.printRecord(
//                        bin.getBin(),
//                        bin.getBinType(),
//                        bin.getBinSubType(),
//                        bin.getLastUpdated(),
//                        bin.getAvailableDate(),
//                        String.join(";", bin.getTxallow()),
//                        bin.getName(),
//                        bin.getShortName(),
//                        bin.getPanlength(),
//                        bin.getIsActive()
//                );
//            }
//            csvPrinter.flush();
//        } catch (IOException e) {
//            throw new RuntimeException("Error creating CSV file: " + e.getMessage(), e);
//        }
//        return file;
//    }
//
//    private void saveCurrentBinAsPrevious(List<BinInfoModel> currentBinList) {
//        createCsvFile(currentBinList, PREVIOUS_BIN_FILE_PATH);
//    }
//
//    private String getCurrentTimestamp() {
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
//        return LocalDateTime.now().format(formatter);
//    }
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////package com.apollo.bins.service;
////
////import jakarta.mail.MessagingException;
////import jakarta.mail.internet.MimeMessage;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.mail.javamail.JavaMailSender;
////import org.springframework.mail.javamail.MimeMessageHelper;
////import org.springframework.stereotype.Service;
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////
////import java.io.File;
////
////@Service
////public class EmailService {
////
////
////    private JavaMailSender mailSender;
////
////    public void sendEmailWithAttachments(String to, String subject, String body, File... attachments) throws MessagingException {
////        MimeMessage message = mailSender.createMimeMessage();
////        MimeMessageHelper helper = new MimeMessageHelper(message, true);
////        helper.setTo(to);
////        helper.setSubject(subject);
////        helper.setText(body);
////
////        for (File attachment : attachments) {
////            if (attachment != null && attachment.exists()) {
////                helper.addAttachment(attachment.getName(), attachment);
////            }
////        }
////
////        mailSender.send(message);
////    }
////
////    public void sendSimpleEmail(String to, String subject, String body) {
////        MimeMessage message = mailSender.createMimeMessage();
////        MimeMessageHelper helper = new MimeMessageHelper(message);
////
////        try {
////            helper.setTo(to);
////            helper.setSubject(subject);
////            helper.setText(body);
////            mailSender.send(message);
////        } catch (MessagingException e) {
////            throw new RuntimeException("Failed to send email: " + e.getMessage());
////        }
////    }
////}
