package com.apollo.bins.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EFTPOSBinResponse {
    private Integer statusCode;
    private String statusMessage;

}
