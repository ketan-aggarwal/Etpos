package com.apollo.bins.exception;

public class BinDataFetchException extends  RuntimeException{
    public BinDataFetchException(String message){
        super(message);
    }

    public BinDataFetchException(String message, Throwable cause){
        super(message,cause);
    }
}
