package com.apollo.bins.exception;

import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@RestControllerAdvice
public class GlobalExceptionHandler {

   @ExceptionHandler(FileGenerationException.class)
    public ResponseEntity<Map<String, Object>> handleFileGenerationException(FileGenerationException ex){
        Map<String,Object> response = new HashMap<>();
        response.put("error","Not able to fetch BIN Details");
        response.put("message",ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(BinDataFetchException.class)
    public ResponseEntity<Map<String, Object>> handleBinDataFetchException(BinDataFetchException ex){
        Map<String,Object> response = new HashMap<>();
        response.put("error","please send valid request");
        response.put("message",ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(FeignException.class)
    public ResponseEntity<Map<String, Object>> handleFeignException(FeignException ex){
        Map<String,Object> response = new HashMap<>();
        response.put("error","external service error");
        response.put("message","Error while connecting external service:"+ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.SERVICE_UNAVAILABLE);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<Map<String, Object>> handleIOException(IOException ex){
        Map<String,Object> response = new HashMap<>();
        response.put("error","I/O error");
        response.put("message","Error while writing data to response:"+ ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleException(Exception ex){
        Map<String,Object> response = new HashMap<>();
        response.put("error","I/O error");
        response.put("message","An error occurred:"+ ex.getMessage());
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
