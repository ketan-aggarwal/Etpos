package com.apollo.bins;

import com.apollo.bins.model.BinInformation;
import com.apollo.bins.service.BinService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

public class ApolloBinController {

    @Mock
    private BinService binService;

    @InjectMocks
    private ApolloBinController apolloBinController;

    private MockMvc mockMvc;

    void setUp(){
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(apolloBinController).build();}


    void downloadCsvBinFile_Success(){
        List<BinInformation> binInformations = new ArrayList<>();
        BinInformation binInformation = new BinInformation();
        binInformation.setBIN("123354");
        binInformation.setBank("Commonwealth Bank of Australia");
        binInformation.setCardType("credit");
        binInformation.setSupportedSchemes("SupportedSchemes");



    }

}
