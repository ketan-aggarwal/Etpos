package com.apollo.bins.service;

import org.springframework.stereotype.Service;

@Service
public interface OAuthService {
    public String getOAuthToken();
}
