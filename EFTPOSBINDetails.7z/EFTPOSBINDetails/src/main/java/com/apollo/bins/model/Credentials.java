package com.apollo.bins.model;

public class Credentials {


    private String clientId;

    private  String grantType;


}
