package com.apollo.bins.feign;

import com.apollo.bins.config.FeignClientConfig;
import com.apollo.bins.model.BinAPIResponse;
import com.apollo.bins.model.BinInformation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;
import java.util.UUID;

@FeignClient(name = "EFTPOSBinDetails", url = "https://sandbox.api.eftpos.io",configuration = FeignClientConfig.class)
public interface BinFeignClient {

    @GetMapping(value= "/bin/v1/bins", produces = "application/json")
    Map<String, Object> getBinDetails(@RequestHeader("Authorization") String bearerToken);


    @GetMapping(value= "/bin/v1/bins/{binId}", produces = "application/json")
    Map<String, Object> getBinDetailsByBinNumber(@RequestHeader("Authorization") String bearerToken, @PathVariable("binId") String binId);





}
