package com.apollo.bins.model;

import com.fasterxml.jackson.annotation.JsonProperty;



public class BinAPIResponse {
    @JsonProperty("BinInformation")
    private BinInformation binInformations;

    public BinInformation getBinInformations() {
        return binInformations;
    }

    public void setBinInformations(BinInformation binInformations) {
        this.binInformations = binInformations;
    }

}
