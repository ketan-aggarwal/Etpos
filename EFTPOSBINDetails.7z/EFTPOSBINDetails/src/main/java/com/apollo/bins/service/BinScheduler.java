//package com.apollo.bins.service;
//
//import com.apollo.bins.feign.BinFeignClient;
//import com.apollo.bins.model.BinInformation;
//import jakarta.mail.MessagingException;
//import org.springframework.stereotype.Service;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//
//
//import java.io.File;
//import java.io.IOException;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.List;
//
//    @Service
//    public class BinScheduler {
//
//        @Autowired
//        private BinService binService;
//
//        @Autowired
//        private CsvService csvService;
//
//
//        @Autowired
//        private EmailService emailService;
//
//        @Autowired
//        private BinFeignClient binFeignClient;
//
//        @Autowired
//        private OAuthService oAuthService;
//
//        private static final String PREVIOUS_BIN_FILE = "previous_bin.csv";
//
//        @Scheduled(cron = "0 0 0 * * ?") // Run every day at midnight
//        public void fetchAndCompareBins() {
//            try {
//                // Fetch current BIN details
//                String oAuthToken = oAuthService.getOAuthToken();
//                List<BinInformation> currentBinList = binService.getBinDetails(oAuthToken);
//
//                // Save the current BIN details to a CSV file
//                String currentFileName = "EFTPOS_bin_details_" + getCurrentTimestamp() + ".csv";
//                File currentFile = csvService.writeCsvFile(currentFileName, currentBinList);
//
//                // Compare with the previous BIN file
//                File previousFile = new File(PREVIOUS_BIN_FILE);
//                if (previousFile.exists()) {
//                    List<BinInformation> previousBinList = csvService.readCsvFile(previousFile);
//                    List<BinInformation> differences = csvService.getDifferences(previousBinList, currentBinList);
//
//                    if (!differences.isEmpty()) {
//                        // Create a differences CSV file
//                        String diffFileName = "EFITPOS_bin_diff_" + getCurrentTimestamp() + ".csv";
//                        File diffFile = csvService.writeCsvFile(diffFileName, differences);
//
//                        // Send email with both files attached
//                        emailService.sendEmailWithAttachments(
//                                "yogesh.kalalkar@wu.com",
//                                "EFTPOS_BIN_List" + getCurrentTimestamp(),
//                                "Hello Abhishek, attached are the below files.",
//                                diffFile, currentFile
//                        );
//
//                        // Replace the previous file with the current one for the next comparison
//                        currentFile.renameTo(previousFile);
//                    } else {
//                        // No differences found; send a simple email
//                        emailService.sendSimpleEmail(
//                                "yogesh.kalalar@wu.com",
//                                "EFTPOSBIN Update: No Changes Found",
//                                "Hello Abhishek,The Downloaded file is same as the last one."
//                        );
//
//                        // Replace the previous file with the current one
//                        currentFile.renameTo(previousFile);
//                    }
//                } else {
//                    // First-time run; just save the current file and notify
//                    currentFile.renameTo(previousFile);
//                    emailService.sendSimpleEmail(
//                            "yogesh.kalalkae@wu.com",
//                            "EFTPOSBIN Update: Initial File Created",
//                            "The initial BIN details file has been created and saved."
//                    );
//                }
//            } catch (IOException | MessagingException e) {
//                throw new RuntimeException("Error during EFTPOS BIN comparison and email process: " + e.getMessage(), e);
//            }
//        }
//
//        private String getCurrentTimestamp() {
//            return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
//        }
//    }
//
