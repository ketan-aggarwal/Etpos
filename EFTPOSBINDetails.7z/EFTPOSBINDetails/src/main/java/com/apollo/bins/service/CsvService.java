package com.apollo.bins.service;

import com.apollo.bins.model.BinInformation;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class CsvService {

    // Write a list of BIN details to a CSV file
    public File writeCsvFile(String fileName, List<BinInformation> binInfoList) throws IOException {
        File file = new File(fileName);
        try (CSVWriter writer = new CSVWriter(new FileWriter(file))) {
            // Write header
            writer.writeNext(new String[]{"BIN","CardType","Bank","SupportedSchemes","PermittedTransactions","IssuedCardLength","isTokenizable"});

            // Write data
            for (BinInformation binInformation : binInfoList) {
                writer.writeNext(new String[]{
                        binInformation.getBIN(),
                        binInformation.getCardType(),
                        binInformation.getBank(),
                        String.join(",",binInformation.getPermittedTransactions()),
                        binInformation.getSupportedSchemes(),
                        binInformation.getIssuedCardLength(),
                        String.valueOf(binInformation.getTokenizable())
                });
            }
        }
        return file;
    }

    // Read BIN details from a CSV file
    public List<BinInformation> readCsvFile(File file) throws IOException {
        List<BinInformation> binInfoList = new ArrayList<>();
        try (CSVReader reader = new CSVReader(new FileReader(file))) {
            String[] nextLine;
            reader.readNext(); // Skip header
            while ((nextLine = reader.readNext()) != null) {
                BinInformation bin = new BinInformation();
                bin.setBIN(nextLine[0]);
                bin.setCardType(nextLine[1]);
                bin.setBank(nextLine[2]);
                bin.setPermittedTransactions(List.of(nextLine[3].split(",")));
                bin.setSupportedSchemes(nextLine[4]);
                bin.setIssuedCardLength(nextLine[5]);
                bin.setTokenizable(Boolean.parseBoolean(nextLine[6]));
                binInfoList.add(bin);
            }
        } catch (CsvValidationException e) {
            throw new RuntimeException(e);
        }
        return binInfoList;
    }

    // Compare two lists of BIN details and return the differences
    public List<BinInformation> getDifferences(List<BinInformation> previous, List<BinInformation> currentBIN) {
        List<BinInformation> differences = new ArrayList<>(currentBIN);
        differences.removeAll(previous); // Keep only items that are different
        return differences;
    }
}