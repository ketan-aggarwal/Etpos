package com.apollo.bins.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.ZonedDateTime;
import java.util.List;

@Getter
@Setter
public class BinInformation {

    @JsonProperty("BIN")
    private String BIN;

    @JsonProperty("SupportedSchemes")
    private String SupportedSchemes;

    @JsonProperty("CardType")
    private String CardType;


    @JsonProperty("PermittedTransactions")
    private List<String> PermittedTransactions;

    @JsonProperty("Bank")
    private  String Bank;


    @JsonProperty("IssuedCardLength")
    private  String IssuedCardLength;

    @JsonProperty("isTokenizable")
    private Boolean isTokenizable;


    public BinInformation() {};

    public Boolean getTokenizable() {
        return isTokenizable;
    }

    public void setTokenizable(Boolean tokenizable) {
        isTokenizable = tokenizable;
    }

    public BinInformation(String BIN, String supportedSchemes, String cardType, List<String> permittedTransactions, String bank, String issuedCardLength, Boolean isTokenizable) {
        this.BIN = BIN;
        SupportedSchemes = supportedSchemes;
        CardType = cardType;
        PermittedTransactions = permittedTransactions;
        Bank = bank;
        IssuedCardLength = issuedCardLength;
        this.isTokenizable = isTokenizable;
    }
}
