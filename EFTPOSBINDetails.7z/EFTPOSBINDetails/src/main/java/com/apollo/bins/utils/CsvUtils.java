package com.apollo.bins.utils;

import com.apollo.bins.model.BinInformation;
import org.springframework.stereotype.Component;

import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

@Component
public class CsvUtils {

    public List<BinInformation> getDifferences(List<BinInformation> previousList, List<BinInformation> newList){
        List<BinInformation> binDifferences = new ArrayList<>();
        for(BinInformation newBin : newList){
            if(!previousList.contains(newBin)){
                binDifferences.add(newBin);
            }
        }
      return binDifferences;
    }


    public  void writeToCsv(List<BinInformation> binInformations, Writer writer){

    }
}
