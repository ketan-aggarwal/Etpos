package com.apollo.bins.feign;
import com.apollo.bins.config.FeignClientConfig;
import com.apollo.bins.model.OAuthResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.Map;

@FeignClient(name = "oauthClient", url="https://sandbox.api.eftpos.io/oauth/v1/token",configuration = FeignClientConfig.class)
public interface OAuthFeignClient {
    @PostMapping(consumes = "application/x-www-form-urlencoded")
    OAuthResponse getToken(
            @RequestHeader("Authorization") String authorization,
            @RequestBody Map<String, ?> formParams
            );
}
