package com.apollo.bins.model;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OAuthResponse {

    private String access_token;
    private String expires_in;
    private String scope;
    private String token_type;



}

