package com.apollo.bins.service;

import com.apollo.bins.model.BinInformation;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Service
public interface BinService {
    /**
     *
     * @param oAuthToken
     * @return
     */
    public List<BinInformation> getBinDetails(String oAuthToken);

    /**
     *
     * @param writer
     * @param binInformations
     * @throws IOException
     */
    public void writeBinDetailsToCsv(PrintWriter writer, List<BinInformation> binInformations) throws IOException;

    /**
     *
     * @param binNumber
     * @param oAuthToken
     * @return
     */
    BinInformation getBinDetail(String binNumber, String oAuthToken);

    /**
     *
     * @param writer
     * @param binInformation
     * @throws IOException
     */
    public void writeBinDetailToCsv(PrintWriter writer, BinInformation binInformation) throws IOException;
}
