package com.apollo.bins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApolloBinDownloadTest {

	@Test
	void contextLoads() {
	}

}
