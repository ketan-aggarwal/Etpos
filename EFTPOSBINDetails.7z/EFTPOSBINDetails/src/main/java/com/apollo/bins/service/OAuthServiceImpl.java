package com.apollo.bins.service;
import com.apollo.bins.feign.OAuthFeignClient;
import com.apollo.bins.model.OAuthResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Base64;
import java.util.Map;

@Service
public class OAuthServiceImpl implements OAuthService {

    @Autowired
    private OAuthFeignClient oAuthFeignClient;

    @Value("${client_Id}")
    private String clientId;

    @Value("${grant_Type}")
    private String grantType;

    @Value("${client_Secrete}")
    private String clientSecrete;

    Logger log = LoggerFactory.getLogger(OAuthServiceImpl.class);


    public String getOAuthToken() {
        log.debug("getting oAuth token started");
        String auth = clientId + ":" + clientSecrete;
        log.debug("auth value:"+auth);
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
        String authorizationHeader = "Basic "+ encodedAuth;
        Map<String, String> formParam = Map.of(
                "client_id",clientId,
                "grant_type",grantType
        );

        OAuthResponse oAuthResponse = oAuthFeignClient.getToken(authorizationHeader,formParam);
        String oAuthToken = "Bearer "+oAuthResponse.getAccess_token();

        return oAuthToken;
    }


}
