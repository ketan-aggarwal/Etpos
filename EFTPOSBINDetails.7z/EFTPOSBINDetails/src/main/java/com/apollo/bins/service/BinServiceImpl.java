package com.apollo.bins.service;

import com.apollo.bins.exception.BinDataFetchException;
import com.apollo.bins.feign.BinFeignClient;
import com.apollo.bins.model.BinInformation;
import com.apollo.bins.utils.CsvUtils;
import feign.FeignException;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class BinServiceImpl implements BinService {

    private static final Logger log = LoggerFactory.getLogger(BinServiceImpl.class);
    @Autowired
    private BinFeignClient binFeignClient;

    @Autowired
    private OAuthService oAuthService;

    @Autowired
    private CsvUtils csvUtils;


    private List<BinInformation> previousBinList;

    private static final String PREVIOUS_BIN_FILE_PATH = "previous_bins.csv";

    /**
     *
     * @param oAuthToken
     * @return BinInformation
     */
    public List<BinInformation> getBinDetails(String oAuthToken) {
        try {
            Map<String, Object> binAPIResponse = binFeignClient.getBinDetails(oAuthToken);
            List<Map<String, Object>> binInformationList = (List<Map<String, Object>>) binAPIResponse.get("binInformation");
            List<BinInformation> binInformations = new ArrayList<>();
            int abc = binInformationList.size();


            for (Map<String, Object> binInfo : binInformationList) {

                    BinInformation binInformation = new BinInformation();
                    binInformation.setBIN((String) binInfo.get("bin"));
                    binInformation.setCardType((String) binInfo.get("binProductSubtype"));
                    binInformation.setBank((String) binInfo.get("eftposIssuerName"));
                    binInformation.setSupportedSchemes((String) binInfo.get("binProductType"));
                    binInformation.setPermittedTransactions((List<String>) binInfo.get("eftposDigitalTransactionTypesAllowed"));
                    binInformation.setIssuedCardLength((String) binInfo.get("panLength"));
                    binInformation.setTokenizable((Boolean) binInfo.get("isTokenizable"));
                    binInformations.add(binInformation);

            }
            return binInformations;
            //return binInformations.stream().limit(200).collect(Collectors.toList());
        }catch (FeignException ex){
            throw new BinDataFetchException("error occured while calling external API:", ex);
        }catch (Exception ex)
        {
            throw new BinDataFetchException("exception occure:",ex);
        }

    }

    /**
     *
     * @param writer
     * @param binInformations
     * @throws IOException
     * @return CSV file
     */
    public void writeBinDetailsToCsv(PrintWriter writer, List<BinInformation> binInformations) throws IOException {
        try(CSVPrinter csvPrinter= new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("BIN","CardType","Bank","SupportedSchemes","PermittedTransactions","IssuedCardLength","isTokenizable"))){
            for(BinInformation binInformation : binInformations){
                csvPrinter.printRecord(
                        binInformation.getBIN(),
                        binInformation.getCardType(),
                        binInformation.getBank(),
                        String.join(",",binInformation.getPermittedTransactions()),
                        binInformation.getSupportedSchemes(),
                        binInformation.getIssuedCardLength(),
                        binInformation.getTokenizable()
                );
            }
        }
    }

    /**
     *
     * @param writer
     * @param binInformation
     * @throws IOException
     * @return CSV file
     */
    public void writeBinDetailToCsv(PrintWriter writer, BinInformation binInformation) throws IOException {
        try(CSVPrinter csvPrinter= new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("BIN","CardType","Bank","SupportedSchemes","PermittedTransactions","IssuedCardLength","isTokenizable"))){
            csvPrinter.printRecord(
                    binInformation.getBIN(),
                    binInformation.getCardType(),
                    binInformation.getBank(),
                    String.join(",",binInformation.getPermittedTransactions()),
                    binInformation.getSupportedSchemes(),
                    binInformation.getIssuedCardLength(),
                    binInformation.getTokenizable()
                );

        }
    }

    /**
     *
     * @param binNumber
     * @param oAuthToken
     * @return BinInformation
     */
    @Override
    public BinInformation getBinDetail(String binNumber, String oAuthToken) {
        try {
        Map<String, Object> binAPIResponse = binFeignClient.getBinDetailsByBinNumber(oAuthToken,binNumber);
        Map<String, Object> binInformation = (Map<String, Object>) binAPIResponse.get("binInformation");

        return mapToBinInformationModel(binInformation);
        }catch (FeignException ex){
            throw new BinDataFetchException("error occured while calling external API:", ex);
        }catch (Exception ex)
        {
            throw new BinDataFetchException("exception occure:",ex);
        }
    }

    /**
     *
     * @param binAPIResponse
     * @return
     */
    private BinInformation mapToBinInformationModel(Map<String, Object> binAPIResponse) {
        BinInformation binInformation = new BinInformation();
        binInformation.setBIN((String) binAPIResponse.get("bin"));
        binInformation.setSupportedSchemes((String) binAPIResponse.get("binProductType"));
        binInformation.setCardType((String) binAPIResponse.get("binProductSubtype"));
        binInformation.setPermittedTransactions((List<String>) binAPIResponse.get("eftposDigitalTransactionTypesAllowed"));
        binInformation.setBank((String) binAPIResponse.get("eftposIssuerName"));
        binInformation.setIssuedCardLength((String) binAPIResponse.get("panLength"));
        binInformation.setTokenizable((Boolean) binAPIResponse.get("isTokenizable"));
        return binInformation;
    }

    /**
     *
     * @throws IOException
     */
    @Scheduled(cron = "0 0 0 * * ?")
    public void compareDataAndSendEmail() throws IOException {
        String oAuthToken = oAuthService.getOAuthToken();
        List<BinInformation> newBinList = getBinDetails(oAuthToken);

        if(previousBinList != null && !newBinList.equals(previousBinList)){

            List<BinInformation> binDifferences = csvUtils.getDifferences(previousBinList,newBinList);

            String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
            File differencesFile = new File("EFTPOSBINList-differences" + timestamp + ".csv");
            File updatedFile = new File("EFTPOSBINList " + timestamp + ".csv");

            // File csvFile = new File("bin-difference.csv");

            if (!binDifferences.isEmpty()) {
                writeBinDetailsToCsv(new PrintWriter(differencesFile), binDifferences);
                writeBinDetailsToCsv(new PrintWriter(updatedFile), binDifferences);
            }

        }

        previousBinList = newBinList;


    }


    public Map<String, File> fetchAndCompareBins() {
        try {
            // Fetch the current list of BINs from the external service
            String oAuthToken = oAuthService.getOAuthToken();
            List<BinInformation> currentBinList = getBinDetails(oAuthToken);
            List<BinInformation> previousBinList = loadPreviousBinList();
            // Compare the lists to identify differences
            List<BinInformation> differenceBinList = compareBinLists(previousBinList, currentBinList);
            // Create updated BIN CSV
            File updatedBinFile = createUpdatedBinCsv(currentBinList);
            // Create difference BIN CSV (only if differences exist)
            File differenceBinFile = null;
            if (!differenceBinList.isEmpty()) {
                differenceBinFile = createDifferenceBinCsv(differenceBinList);
            }

                // Replace the previous BIN file with the updated file for the next comparison
                saveCurrentBinAsPrevious(currentBinList);
                // Return both files in a map
                Map<String, File> resultFiles = new HashMap<>();
                resultFiles.put("EFTPOSBinupdated", updatedBinFile);
                resultFiles.put("EFTPOSBindifference", differenceBinFile);
                return resultFiles;
        } catch (Exception e) {
            throw new RuntimeException("Error while fetching and comparing BINs: " + e.getMessage(), e);

        }
    }

    private void saveCurrentBinAsPrevious(List<BinInformation> currentBinList) {
        createCsvFile(currentBinList, PREVIOUS_BIN_FILE_PATH);
    }

    private File createDifferenceBinCsv(List<BinInformation> differenceBinList) {
        return createCsvFile(differenceBinList, "EFTPOSBinDifference_bins_" + getCurrentTimestamp() + ".csv");

    }

    private File createUpdatedBinCsv(List<BinInformation> currentBinList) {
        return createCsvFile(currentBinList, "EFTPOSBinUpdated_bins_" + getCurrentTimestamp() + ".csv");

    }

    private File createCsvFile(List<BinInformation> binList, String fileName) {
        File file = new File(fileName);
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(file.getPath()));
             CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader(
                     "BIN","CardType","Bank","SupportedSchemes","PermittedTransactions","IssuedCardLength","isTokenizable"))) {

            for (BinInformation  binInformation : binList) {
                csvPrinter.printRecord(
                        binInformation.getBIN(),
                        binInformation.getCardType(),
                        binInformation.getBank(),
                        String.join(",",binInformation.getPermittedTransactions()),
                        binInformation.getSupportedSchemes(),
                        binInformation.getIssuedCardLength(),
                        binInformation.getTokenizable()
                );
            }
            csvPrinter.flush();
        } catch (IOException e) {
            throw new RuntimeException("Error creating CSV file: " + e.getMessage(), e);
        }
        return file;
    }

    private String getCurrentTimestamp() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        return LocalDateTime.now().format(formatter);
    }

    private List<BinInformation> compareBinLists(List<BinInformation> previousBinList, List<BinInformation> currentBinList) {
        Set<String> previousBins = previousBinList.stream().map(BinInformation::getBIN).collect(Collectors.toSet());
        return currentBinList.stream()
                .filter(bin -> !previousBins.contains(bin.getBIN()))
                .collect(Collectors.toList());

    }

    private List<BinInformation> loadPreviousBinList() {
        File file = new File(PREVIOUS_BIN_FILE_PATH);
        if (!file.exists()) {
            return Collections.emptyList();
        }

        try (BufferedReader reader = Files.newBufferedReader(Paths.get(PREVIOUS_BIN_FILE_PATH))) {
            return reader.lines()
                    .skip(1) // Skip header row
                    .map(line -> {
                        String[] parts = line.split(",");
                        return new BinInformation(parts[0], parts[1], parts[2], Arrays.asList(parts[3].split(";")), parts[4], parts[5], Boolean.parseBoolean(parts[6]));
                    })
                    .collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException("Error reading previous BIN file: " + e.getMessage(), e);
        }
    }

}







