package com.apollo.bins.controller;

import com.apollo.bins.feign.BinFeignClient;
import com.apollo.bins.feign.OAuthFeignClient;
import com.apollo.bins.model.BinInformation;
import com.apollo.bins.model.EFTPOSBinResponse;
import com.apollo.bins.service.BinService;
import com.apollo.bins.service.BinServiceImpl;
import com.apollo.bins.service.OAuthService;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ApolloAPIBinController {

    @Autowired
    private OAuthFeignClient oAuthFeignClient;
    @Autowired
    private BinFeignClient binFeignClient;

    @Autowired
    private OAuthService oAuthService;

    @Autowired
    private BinService binService;

    @Autowired
    private BinServiceImpl binServiceImpl;


    Logger log = LoggerFactory.getLogger(ApolloAPIBinController.class);


    /**
     * Below method responsible to return List of BINS
     *
     * @return binApiResponse
     */
    @GetMapping("/binDetails")
    public ResponseEntity<EFTPOSBinResponse> getBinDetails() throws IOException {
        Map<String, File> BinEFTPOSFile = binServiceImpl.fetchAndCompareBins();
        log.trace("getting Bin details in process");
      //  String oAuthToken = oAuthService.getOAuthToken();
        log.debug("getting oAuthtoken from oAuthService EFTPOS");
      //  List<BinInformation> binApiResponse = binService.getBinDetails(oAuthToken);
//        response.setContentType("text/csv");
//        response.setHeader("Content-Disposition", "attachment; file=EFTPOSBIN-details.csv");
//        binService.writeBinDetailsToCsv(response.getWriter(), binApiResponse);
        EFTPOSBinResponse eFTPOSBinResponse = new EFTPOSBinResponse();
        if(BinEFTPOSFile != null) {
            eFTPOSBinResponse.setStatusCode(200);
            eFTPOSBinResponse.setStatusMessage("EFTPOSBin file downloaded successfully");
        }
        else{
            eFTPOSBinResponse.setStatusCode(500);
            eFTPOSBinResponse.setStatusMessage("Getting Internal server error please check your code");
        }
        return new ResponseEntity<>(eFTPOSBinResponse, HttpStatusCode.valueOf(eFTPOSBinResponse.getStatusCode()));

    }

    /**
     * @param response
     * @param binNumber
     * @throws IOException
     * @response binInformation
     */
    @GetMapping("/binDetails/{binNumber}")
    public void getBinDetail(HttpServletResponse response, @PathVariable String binNumber) throws IOException {
        String oAuthToken = oAuthService.getOAuthToken();
        BinInformation binApiResponse = binService.getBinDetail(binNumber, oAuthToken);
        log.debug("getting single BIN Details from EFTPOS");
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; file=EFTPOSBIN-details.csv");
        binService.writeBinDetailToCsv(response.getWriter(), binApiResponse);
    }

}
